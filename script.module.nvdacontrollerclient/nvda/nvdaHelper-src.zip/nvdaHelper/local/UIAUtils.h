#ifndef NVDAHELPERLOCAL_UIAUTILS_H
#define NVDAHELPERLOCAL_UIAUTILS_H

#include <uiAutomationCore.h>

PROPERTYID registerUIAProperty(GUID* guid, LPCWSTR programmaticName, UIAutomationType propertyType);

#endif

